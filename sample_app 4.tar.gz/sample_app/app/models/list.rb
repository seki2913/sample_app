class List < ApplicationRecord
    attachment :image
#  def new
#     @list = List.new
#  end
  
end

#   def new 
#     @image = Image.new
#   end 
