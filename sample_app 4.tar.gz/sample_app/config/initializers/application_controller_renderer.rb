# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '818f56e6913227541a3b0b1cfe6a9e2f3ec9d562009c48c4998587e4688b5c0b0d5011db2f202250b4154d4f273af3d0d5a47bd9a422906182714f5d653d9ef5'